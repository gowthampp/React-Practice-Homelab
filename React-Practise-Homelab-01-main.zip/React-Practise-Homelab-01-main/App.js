
import './App.css';
import Book from './Component/Book';


function App() {
  return (
    <div>
      <Book name="Book name 1"author="author name 1"/>
      <Book name="Book name 2"author="author name 2"/>
      <Book name="Book name 3"author="author name 3"/>
      <Book name="Book name 4"author="author name 4"/>
      <Book name="Book name 5"author="author name 5"/>

    </div>
  );
}

export default App;
